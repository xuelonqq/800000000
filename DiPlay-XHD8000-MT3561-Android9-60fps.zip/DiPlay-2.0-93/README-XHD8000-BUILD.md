# DiPlay — XHD-8000 / MT3561 / Android 9 / 60 FPS

This branch is prepared for the user's XHD-8000 head unit:

- Android 9 / API 28
- MediaTek MT3561/MT3561SV family
- Legacy WifiP2pManager path for Android 9
- Wi-Fi P2P is the default wireless mode on Android 9
- External Wi-Fi remains available as a fallback
- CarPlay display preference is fixed to 60 FPS
- H.264 remains the safe default

## Build an APK with GitHub Actions

1. Create a GitHub repository (a fork is fine).
2. Upload this entire project, preserving `.github/workflows/xhd8000-apk.yml`.
3. Push the branch named `xhd8000-android9`, or change the workflow trigger if desired.
4. Open the repository on GitHub → **Actions** → **Build XHD-8000 Android 9 APK**.
5. Click **Run workflow**.
6. Wait for the green check.
7. Open the completed workflow run → **Artifacts**.
8. Download `DiPlay-XHD8000-MT3561-Android9-60fps`.
9. Unzip the artifact and install the APK on the XHD-8000.

## Important

This workflow builds a debug APK from public source. It does not contain private/release CarPlay authentication assets or a release signing key. If the app installs but CarPlay authentication stops after Bluetooth/Wi-Fi connection, that is an authentication/runtime-identity issue rather than an Android 9 installation issue.

## First wireless test

On the XHD-8000:

1. Pair the iPhone in Android Bluetooth settings.
2. Open DiPlay → select the iPhone.
3. Select **Wi-Fi P2P（Android 9 / MT3561）**.
4. Leave Wi-Fi enabled.
5. Start Wireless CarPlay.
6. If it fails, export the DiPlay diagnostic report before changing settings.

Record the exact stage: `Bluetooth paired` → `Wi-Fi P2P group created` → `iPhone sees CarPlay` → `Starting CarPlay` → `CarPlay connected`.
