package com.shilapi.xcertplay.hud

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.util.Log
import java.security.MessageDigest

/** Ordinary-app IPC to the real stock receiver. No shell, local socket or permission grant. */
internal class BydStandaloneHudOutput private constructor(context: Context) {    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("byd_standalone_hud", Context.MODE_PRIVATE)
    private val session = BydStandaloneSession(
        send = { packet ->
            app.sendBroadcast(Intent("byd.hud.NAVIGATION").setComponent(TARGET)
                .putExtra("normal", packet).addFlags(Intent.FLAG_RECEIVER_FOREGROUND))
            Log.d(TAG, "派发 uid=${Process.myUid()} 字节=${packet.split(',').size}")
        },
        rememberPendingClear = { pending ->
            check(prefs.edit().putBoolean("pending_clear", pending).commit()) { "无法持久化 HUD 清理状态" }
        },
        needsRecovery = prefs.getBoolean("pending_clear", false),
    )

    init {
        Log.i(TAG, "独立导航已就绪 uid=${Process.myUid()} 辅助=none")
        // Retain the journal if dispatch fails; the next scheduled tick retries.
        runCatching { session.clear() }.onFailure { Log.w(TAG, "启动清理将重试", it) }
    }

    fun update(icon: Int, exit: Int, distanceMeters: Int, road: String) =
        session.update(icon, exit, distanceMeters, road)
    fun clear() = session.clear()

    companion object {
        private const val TAG = "BYD-Standalone-Live"
        private val TARGET = ComponentName("com.byd.clusterdebug", "com.byd.clusterdebug.BroadcastReceiverCAN")
        @Volatile var syntheticHold = false

        fun create(context: Context): BydStandaloneHudOutput? =
            if (available(context)) BydStandaloneHudOutput(context) else null

        /** Enable production and diagnostic packages only on the physically tested firmware. */
        fun available(context: Context): Boolean {
            // A standalone guard: lint only treats a bare version check as a flow guard, and the
            // signing APIs below are all API 28.
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
            if (context.packageName !in setOf(
                    "com.andrerinas.headunitrevived", "com.shihab.diplay",
                    "com.andrerinas.headunitrevived.bydhudtest", "com.shihab.diplay.hudtest")) return false
            if (Build.FINGERPRINT != "BYD-AUTO/IVI/IVI:13/TP1A.220624.014/eng.build20260722.221155:user/release-keys") return false
            return runCatching {
                val manager = context.packageManager
                val info = manager.getPackageInfo(TARGET.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                val receiver = manager.getReceiverInfo(TARGET, 0)
                val signers = info.signingInfo?.apkContentsSigners ?: return false
                info.versionCodeCompat() == 10601004L &&
                    info.applicationInfo!!.flags and ApplicationInfo.FLAG_SYSTEM != 0 &&
                    receiver.enabled && receiver.exported && receiver.permission.isNullOrEmpty() &&
                    signers.size == 1 && MessageDigest.getInstance("SHA-256").digest(signers[0].toByteArray())
                        .joinToString("") { "%02x".format(it.toInt() and 255) } ==
                        "efe3ca8ada0d10c655c3df9910ad2ebc121a47d9a6358434eb24074309933efc"
            }.getOrDefault(false)
        }
    }
}

/**
 * PackageInfo.longVersionCode is API 28. Every caller above already refuses to run below 28, but
 * the explicit check keeps lint and the compiler honest on the API 24 floor.
 */
@Suppress("DEPRECATION")
private fun PackageInfo.versionCodeCompat(): Long =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) longVersionCode else versionCode.toLong()
